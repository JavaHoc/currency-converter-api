package com.api.currencyconverter.repository;

import com.api.currencyconverter.entity.ConversionHistory;
import com.api.currencyconverter.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ConversionRepository
        extends JpaRepository<ConversionHistory, Long> {

    List<ConversionHistory> findByUser(User user);
}

