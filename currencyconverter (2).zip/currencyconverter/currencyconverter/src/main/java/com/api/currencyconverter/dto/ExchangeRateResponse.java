package com.api.currencyconverter.dto;

import com.api.currencyconverter.entity.ConversionHistory;

import java.math.BigDecimal;
import java.util.Map;

public class ExchangeRateResponse {
    private Map<String, BigDecimal> conversion_rates;

    public Map<String, BigDecimal> getConversion_rates() {
        return conversion_rates;
    }

    public ConversionResponse toDto(ConversionHistory history) {
        ConversionResponse dto = new ConversionResponse();
        dto.setFromCurrency(history.getFromCurrency());
        dto.setToCurrency(history.getToCurrency());
        dto.setAmount(history.getAmount());
        dto.setConvertedAmount(history.getConvertedAmount());
        dto.setConversionTime(history.getConversionTime());
        return dto;
    }

}

