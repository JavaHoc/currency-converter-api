package com.api.currencyconverter.controller;

import com.api.currencyconverter.entity.ConversionHistory;
import com.api.currencyconverter.entity.User;
import com.api.currencyconverter.repository.ConversionRepository;
import com.api.currencyconverter.repository.UserRepository;
import com.api.currencyconverter.service.ConversionService;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/currency")
public class CurrencyController {

    private final ConversionService conversionService;
    private final UserRepository userRepository;
    private final ConversionRepository conversionRepository;

    public CurrencyController(ConversionService conversionService,
                              UserRepository userRepository,
                              ConversionRepository conversionRepository) {
        this.conversionService = conversionService;
        this.userRepository = userRepository;
        this.conversionRepository = conversionRepository;
    }

    @PostMapping("/convert")
    public ConversionHistory convert(
            @RequestHeader("X-API-KEY") String apiKey,
            @RequestParam String from,
            @RequestParam String to,
            @RequestParam BigDecimal amount) {

        User user = userRepository.findByApiKey(apiKey)
                .orElseThrow(() -> new RuntimeException("Invalid API Key"));

        return conversionService.convertAndSave(from, to, amount, user);
    }

    @GetMapping("/history")
    public List<ConversionHistory> history(
            @RequestHeader("X-API-KEY") String apiKey) {

        User user = userRepository.findByApiKey(apiKey)
                .orElseThrow(() -> new RuntimeException("Invalid API Key"));

        return conversionRepository.findByUser(user);
    }
}



