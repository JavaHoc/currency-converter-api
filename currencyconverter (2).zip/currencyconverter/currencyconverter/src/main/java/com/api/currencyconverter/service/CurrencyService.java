package com.api.currencyconverter.service;

import com.api.currencyconverter.dto.ExchangeRateResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
@Service
public class CurrencyService {

    @Value("${exchange.api.key}")
    private String apiKey;

    @Value("${exchange.api.url}")
    private String baseUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public BigDecimal convert(String from, String to, BigDecimal amount) {

        String url = baseUrl + "/" + apiKey + "/latest/" + from;

        ExchangeRateResponse response =
                restTemplate.getForObject(url, ExchangeRateResponse.class);

        BigDecimal rate = response.getConversion_rates().get(to);
        return amount.multiply(rate);
    }
}


