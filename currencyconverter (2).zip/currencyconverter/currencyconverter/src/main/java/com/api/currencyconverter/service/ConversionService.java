package com.api.currencyconverter.service;

import com.api.currencyconverter.entity.ConversionHistory;
import com.api.currencyconverter.entity.User;
import com.api.currencyconverter.repository.ConversionRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
public class ConversionService {

    private final CurrencyService currencyService;
    private final ConversionRepository repository;

    public ConversionService(CurrencyService currencyService,
                             ConversionRepository repository) {
        this.currencyService = currencyService;
        this.repository = repository;
    }

    public ConversionHistory convertAndSave(
            String from,
            String to,
            BigDecimal amount,
            User user) {

        BigDecimal converted =
                currencyService.convert(from, to, amount);

        ConversionHistory history = new ConversionHistory();
        history.setFromCurrency(from);
        history.setToCurrency(to);
        history.setAmount(amount);
        history.setConvertedAmount(converted);
        history.setConversionTime(LocalDateTime.now());
        history.setUser(user);

        return repository.save(history);
    }
}

