package com.api.currencyconverter.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http,
                                           ApiKeyFilter apiKeyFilter) throws Exception {

        http
                // Disable default security mechanisms
                .csrf(csrf -> csrf.disable())
                .formLogin(form -> form.disable())
                .httpBasic(basic -> basic.disable())

                // Authorization rules
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/h2-console/**").permitAll()
                        .anyRequest().permitAll()
                )

                // Required for H2 console iframe
                .headers(headers -> headers
                        .frameOptions(frame -> frame.disable())
                )

                // API Key filter
                .addFilterBefore(apiKeyFilter,
                        UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
